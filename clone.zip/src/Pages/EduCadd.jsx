import React from 'react'

const EduCadd = () => {
  return (
    <div>
      EduCadd
    </div>
  )
}

export default EduCadd
