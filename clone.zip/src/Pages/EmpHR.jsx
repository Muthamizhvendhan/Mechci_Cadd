import React from 'react'
import Products from '../Components/Product/Products'

const EmpHR = () => {
  return (
    <div>
      <Products />
    </div>
  )
}

export default EmpHR
