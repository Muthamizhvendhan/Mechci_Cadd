import React from 'react'
import Products from '../Components/Product/Products'
import Cta from '../Components/About/Cta'

const EnggDesign = () => {
  return (
    <div>
      <Products /> 
      <Cta/>
    </div>
  )
}

export default EnggDesign
