export const Leads = [
    {
        img: "https://spacema-dev.com/elevate/assets/images/team/4.jpg",
        name: "Jane Smith",
        role: "Role: Graphic Designer"
    },
    {
        img: "https://spacema-dev.com/elevate/assets/images/team/5.jpg",
        name: "Emily Brown",
        role: "Role: UX Designer"
    },
    {
        img: "https://spacema-dev.com/elevate/assets/images/team/7.jpg",
        name: "Sarah Johnson",
        role: "Role: Content Writer"
    },
    {
        img: "https://spacema-dev.com/elevate/assets/images/team/8.jpg",
        name: "David Wilson",
        role: "Role: Project Manager"
    },
]


export const clients = [
    "https://spacema-dev.com/elevate/assets/images/team/1.jpg",
    "https://spacema-dev.com/elevate/assets/images/team/2.jpg",
    "https://spacema-dev.com/elevate/assets/images/team/3.jpg",
    "https://spacema-dev.com/elevate/assets/images/team/4.jpg",
    "https://spacema-dev.com/elevate/assets/images/team/5.jpg",
    "https://spacema-dev.com/elevate/assets/images/team/6.jpg",
    "https://spacema-dev.com/elevate/assets/images/team/7.jpg",
    "https://spacema-dev.com/elevate/assets/images/team/8.jpg",
    "https://spacema-dev.com/elevate/assets/images/team/4.jpg",
    "https://spacema-dev.com/elevate/assets/images/team/2.jpg",
]