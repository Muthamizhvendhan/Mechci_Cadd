import React from 'react'
import OurTeam from '../About/OurTeam'

const Experts = () => {
  return (
    <div>
      <OurTeam/>
    </div>
  )
}

export default Experts
